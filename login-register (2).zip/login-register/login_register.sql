-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 02, 2024 at 05:27 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `login_register`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_users`
--

CREATE TABLE `admin_users` (
  `idnumber` int(11) NOT NULL,
  `full_name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `yearlevel` int(4) NOT NULL,
  `address` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_users`
--

INSERT INTO `admin_users` (`idnumber`, `full_name`, `username`, `gender`, `email`, `yearlevel`, `address`, `password`) VALUES
(2, 'admin1', 'admin1', 'Male', 'admin1@gmail.com', 3, 'PC Hills', 'admin1');

-- --------------------------------------------------------

--
-- Table structure for table `sitin_student`
--

CREATE TABLE `sitin_student` (
  `idnumber` int(11) NOT NULL,
  `full_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `yearlevel` int(10) NOT NULL,
  `purpose` varchar(50) NOT NULL,
  `lab` int(4) NOT NULL,
  `remaining_session` int(50) NOT NULL,
  `time_in` datetime NOT NULL DEFAULT current_timestamp(),
  `time_out` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sitin_student`
--

INSERT INTO `sitin_student` (`idnumber`, `full_name`, `email`, `yearlevel`, `purpose`, `lab`, `remaining_session`, `time_in`, `time_out`) VALUES
(1, 'Albert Einstein', 'roy@gmail.com', 3, 'Python', 524, 28, '2024-04-23 12:11:28', '2024-04-23 12:11:52'),
(1, 'Albert Einstein', 'roy@gmail.com', 3, 'java', 526, 28, '2024-04-23 12:11:47', '2024-04-23 12:11:52');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `idnumber` int(11) NOT NULL,
  `full_name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `yearlevel` int(4) NOT NULL,
  `address` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`idnumber`, `full_name`, `username`, `gender`, `email`, `yearlevel`, `address`, `password`) VALUES
(1, 'Albert Einstein', 'roy', 'Male', 'roy@gmail.com', 3, 'pards', 'roy123'),
(2, 'sean', 'sean', 'Male', 'sean@gmail.com', 3, 'sean', 'sean123'),
(3, 'Roy', 'roy', 'Male', 'roy@gmail.com', 3, 'roy', 'roy123'),
(4, 'Kierzen Ivan JAy BOoc', 'booc', 'Male', 'booc@gmail.com', 3, 'PC Hills', 'booc123'),
(5, 'dereck', 'dereck', 'Male', 's@gmail.com', 3, 'hi', 'dereck123');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 02, 2024 at 05:27 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `login_register`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_users`
--

CREATE TABLE `admin_users` (
  `idnumber` int(11) NOT NULL,
  `full_name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `yearlevel` int(4) NOT NULL,
  `address` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_users`
--

INSERT INTO `admin_users` (`idnumber`, `full_name`, `username`, `gender`, `email`, `yearlevel`, `address`, `password`) VALUES
(2, 'admin1', 'admin1', 'Male', 'admin1@gmail.com', 3, 'PC Hills', 'admin1');

-- --------------------------------------------------------

--
-- Table structure for table `sitin_student`
--

CREATE TABLE `sitin_student` (
  `idnumber` int(11) NOT NULL,
  `full_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `yearlevel` int(10) NOT NULL,
  `purpose` varchar(50) NOT NULL,
  `lab` int(4) NOT NULL,
  `remaining_session` int(50) NOT NULL,
  `time_in` datetime NOT NULL DEFAULT current_timestamp(),
  `time_out` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sitin_student`
--

INSERT INTO `sitin_student` (`idnumber`, `full_name`, `email`, `yearlevel`, `purpose`, `lab`, `remaining_session`, `time_in`, `time_out`) VALUES
(1, 'Albert Einstein', 'roy@gmail.com', 3, 'Python', 524, 28, '2024-04-23 12:11:28', '2024-04-23 12:11:52'),
(1, 'Albert Einstein', 'roy@gmail.com', 3, 'java', 526, 28, '2024-04-23 12:11:47', '2024-04-23 12:11:52');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `idnumber` int(11) NOT NULL,
  `full_name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `yearlevel` int(4) NOT NULL,
  `address` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`idnumber`, `full_name`, `username`, `gender`, `email`, `yearlevel`, `address`, `password`) VALUES
(1, 'Albert Einstein', 'roy', 'Male', 'roy@gmail.com', 3, 'pards', 'roy123'),
(2, 'sean', 'sean', 'Male', 'sean@gmail.com', 3, 'sean', 'sean123'),
(3, 'Roy', 'roy', 'Male', 'roy@gmail.com', 3, 'roy', 'roy123'),
(4, 'Kierzen Ivan JAy BOoc', 'booc', 'Male', 'booc@gmail.com', 3, 'PC Hills', 'booc123'),
(5, 'dereck', 'dereck', 'Male', 's@gmail.com', 3, 'hi', 'dereck123');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 02, 2024 at 05:27 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `login_register`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_users`
--

CREATE TABLE `admin_users` (
  `idnumber` int(11) NOT NULL,
  `full_name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `yearlevel` int(4) NOT NULL,
  `address` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_users`
--

INSERT INTO `admin_users` (`idnumber`, `full_name`, `username`, `gender`, `email`, `yearlevel`, `address`, `password`) VALUES
(2, 'admin1', 'admin1', 'Male', 'admin1@gmail.com', 3, 'PC Hills', 'admin1');

-- --------------------------------------------------------

--
-- Table structure for table `sitin_student`
--

CREATE TABLE `sitin_student` (
  `idnumber` int(11) NOT NULL,
  `full_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `yearlevel` int(10) NOT NULL,
  `purpose` varchar(50) NOT NULL,
  `lab` int(4) NOT NULL,
  `remaining_session` int(50) NOT NULL,
  `time_in` datetime NOT NULL DEFAULT current_timestamp(),
  `time_out` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sitin_student`
--

INSERT INTO `sitin_student` (`idnumber`, `full_name`, `email`, `yearlevel`, `purpose`, `lab`, `remaining_session`, `time_in`, `time_out`) VALUES
(1, 'Albert Einstein', 'roy@gmail.com', 3, 'Python', 524, 28, '2024-04-23 12:11:28', '2024-04-23 12:11:52'),
(1, 'Albert Einstein', 'roy@gmail.com', 3, 'java', 526, 28, '2024-04-23 12:11:47', '2024-04-23 12:11:52');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `idnumber` int(11) NOT NULL,
  `full_name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `yearlevel` int(4) NOT NULL,
  `address` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`idnumber`, `full_name`, `username`, `gender`, `email`, `yearlevel`, `address`, `password`) VALUES
(1, 'Albert Einstein', 'roy', 'Male', 'roy@gmail.com', 3, 'pards', 'roy123'),
(2, 'sean', 'sean', 'Male', 'sean@gmail.com', 3, 'sean', 'sean123'),
(3, 'Roy', 'roy', 'Male', 'roy@gmail.com', 3, 'roy', 'roy123'),
(4, 'Kierzen Ivan JAy BOoc', 'booc', 'Male', 'booc@gmail.com', 3, 'PC Hills', 'booc123'),
(5, 'dereck', 'dereck', 'Male', 's@gmail.com', 3, 'hi', 'dereck123');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 02, 2024 at 05:27 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `login_register`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_users`
--

CREATE TABLE `admin_users` (
  `idnumber` int(11) NOT NULL,
  `full_name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `yearlevel` int(4) NOT NULL,
  `address` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_users`
--

INSERT INTO `admin_users` (`idnumber`, `full_name`, `username`, `gender`, `email`, `yearlevel`, `address`, `password`) VALUES
(2, 'admin1', 'admin1', 'Male', 'admin1@gmail.com', 3, 'PC Hills', 'admin1');

-- --------------------------------------------------------

--
-- Table structure for table `sitin_student`
--

CREATE TABLE `sitin_student` (
  `idnumber` int(11) NOT NULL,
  `full_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `yearlevel` int(10) NOT NULL,
  `purpose` varchar(50) NOT NULL,
  `lab` int(4) NOT NULL,
  `remaining_session` int(50) NOT NULL,
  `time_in` datetime NOT NULL DEFAULT current_timestamp(),
  `time_out` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sitin_student`
--

INSERT INTO `sitin_student` (`idnumber`, `full_name`, `email`, `yearlevel`, `purpose`, `lab`, `remaining_session`, `time_in`, `time_out`) VALUES
(1, 'Albert Einstein', 'roy@gmail.com', 3, 'Python', 524, 28, '2024-04-23 12:11:28', '2024-04-23 12:11:52'),
(1, 'Albert Einstein', 'roy@gmail.com', 3, 'java', 526, 28, '2024-04-23 12:11:47', '2024-04-23 12:11:52');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `idnumber` int(11) NOT NULL,
  `full_name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `yearlevel` int(4) NOT NULL,
  `address` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`idnumber`, `full_name`, `username`, `gender`, `email`, `yearlevel`, `address`, `password`) VALUES
(1, 'Albert Einstein', 'roy', 'Male', 'roy@gmail.com', 3, 'pards', 'roy123'),
(2, 'sean', 'sean', 'Male', 'sean@gmail.com', 3, 'sean', 'sean123'),
(3, 'Roy', 'roy', 'Male', 'roy@gmail.com', 3, 'roy', 'roy123'),
(4, 'Kierzen Ivan JAy BOoc', 'booc', 'Male', 'booc@gmail.com', 3, 'PC Hills', 'booc123'),
(5, 'dereck', 'dereck', 'Male', 's@gmail.com', 3, 'hi', 'dereck123');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 02, 2024 at 05:27 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `login_register`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_users`
--

CREATE TABLE `admin_users` (
  `idnumber` int(11) NOT NULL,
  `full_name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `yearlevel` int(4) NOT NULL,
  `address` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_users`
--

INSERT INTO `admin_users` (`idnumber`, `full_name`, `username`, `gender`, `email`, `yearlevel`, `address`, `password`) VALUES
(2, 'admin1', 'admin1', 'Male', 'admin1@gmail.com', 3, 'PC Hills', 'admin1');

-- --------------------------------------------------------

--
-- Table structure for table `sitin_student`
--

CREATE TABLE `sitin_student` (
  `idnumber` int(11) NOT NULL,
  `full_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `yearlevel` int(10) NOT NULL,
  `purpose` varchar(50) NOT NULL,
  `lab` int(4) NOT NULL,
  `remaining_session` int(50) NOT NULL,
  `time_in` datetime NOT NULL DEFAULT current_timestamp(),
  `time_out` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sitin_student`
--

INSERT INTO `sitin_student` (`idnumber`, `full_name`, `email`, `yearlevel`, `purpose`, `lab`, `remaining_session`, `time_in`, `time_out`) VALUES
(1, 'Albert Einstein', 'roy@gmail.com', 3, 'Python', 524, 28, '2024-04-23 12:11:28', '2024-04-23 12:11:52'),
(1, 'Albert Einstein', 'roy@gmail.com', 3, 'java', 526, 28, '2024-04-23 12:11:47', '2024-04-23 12:11:52');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `idnumber` int(11) NOT NULL,
  `full_name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `yearlevel` int(4) NOT NULL,
  `address` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`idnumber`, `full_name`, `username`, `gender`, `email`, `yearlevel`, `address`, `password`) VALUES
(1, 'Albert Einstein', 'roy', 'Male', 'roy@gmail.com', 3, 'pards', 'roy123'),
(2, 'sean', 'sean', 'Male', 'sean@gmail.com', 3, 'sean', 'sean123'),
(3, 'Roy', 'roy', 'Male', 'roy@gmail.com', 3, 'roy', 'roy123'),
(4, 'Kierzen Ivan JAy BOoc', 'booc', 'Male', 'booc@gmail.com', 3, 'PC Hills', 'booc123'),
(5, 'dereck', 'dereck', 'Male', 's@gmail.com', 3, 'hi', 'dereck123');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
